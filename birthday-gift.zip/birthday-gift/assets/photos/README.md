Put your photos here, named photo-01.jpg, photo-02.jpg ... photo-12.jpg
(.jpeg / .png / .webp also work). Tip: resize to about 1600px wide first so the page loads fast.
